﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server.enums
{
    public enum ServerStatus
    {
        New = 0,
        Running = 1,
        Stop = 2,
    }
}
