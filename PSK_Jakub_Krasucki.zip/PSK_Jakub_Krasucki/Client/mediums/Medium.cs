﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client.mediums
{
    public abstract class Medium
    {
        public abstract string QA(string request);
    }
}
